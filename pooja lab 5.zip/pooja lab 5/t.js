function circleDraw(event) {
    // <svg width="10px" height="10px"></svg>
    console.log(event)
}